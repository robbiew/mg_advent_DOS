
 Welcome to the D32 door programming library!  You've just stumbled upon
 what I consider to be one of the most flexible door writing libraries ever
 created.

 Hopefully you've unzipped your distribution archive with directories
 intact.  If you did, you should have the following directory tree after
 unzipping:

      DOCS     - Contains documentation for the D32 library and all its
                 functions.  It also contains some general Door32
                 information as well, and the WHATSNEW for this current
                 release.
      SOURCE   - Contains the source code to the D32 library.
      EXAMPLES - Contains source code to various example door games.  Some
                 are very minimal, others may be substancial games.  New
                 examples will be added as time permits.

 If you do not have this directory tree then you will have all the files
 stuck in one directory.  This won't effect the functionality of the
 library but will take away a little organization! 

 See the DOCS for more information.  Thanks for checking this library out!

 -g00r00
